#include<iostream>
#include<string>
#include<stdlib.h>
#include<stdio.h>
using namespace std;

struct room{
	int roomnumber;
	string guestname;
	bool occupied;
	string roomtype;
	
	room* next;
};
room* headr=0;
struct node{
	int orderNumber,quantity;
	string foodName;
	double price;
	node* next;
};
node* heada=0;
node* taila=0,newnode;
node* headc=0;
node* tailc=0;
node* head1=0;
node* tail=0;


room* addRoom(room* headr,int roomnumber,bool occupied,string guestname,string roomtype){

	
	room* newRoom=new room();
	
	newRoom->roomnumber=roomnumber;
	newRoom->guestname=guestname;
	newRoom->occupied=false;
	newRoom->roomtype=roomtype;
	newRoom->next=0;
	if(headr==0)
	{
		headr=newRoom;
	}
	else{
	room* temp=headr;
	while(temp->next!=0)
	{
		temp=temp->next;
	}
 temp->next=newRoom;
	}
	return headr;

	
}

 room* checkIn(	int roomnumber, string guestname,bool occupied,room* headr) {
   
    room* newRoom=new room();
	newRoom->roomnumber=roomnumber;
	
        room*  temp= headr;
        while (temp != 0) {
            if (temp->roomnumber == roomnumber) {
                if (temp->occupied==true) {
                    cout << "Room " << roomnumber << " is already occupied.\n" << endl;
                    
                } else {
                	cout<<"Enter the name of guest:";
                	cin>>guestname;
                    temp->guestname = guestname;
                    temp->occupied = true;
                    cout << guestname << " checked into room " << roomnumber << ".\n" << endl;
                   
                }
            }
            temp = temp->next;
        }
       
        return headr;
       
    }
    room* cancelReservation(string guestname, room* headr)
    {
    	if (headr == 0)
    {
        cout << "List is empty!\n" << endl;
        return 0;
    }
    
    if (guestname == headr->guestname)
    {
        room* temp = headr;
        headr= headr->next;
        delete temp;
        return headr;
    }
    
    room* current = headr;
    while (current->next != 0)
    {
        if (guestname == current->next->guestname)
        {
            room* temp = current->next;
            current->next = current->next->next;
            delete temp;
        }
        current = current->next;
    }
    
    
    return headr;
    
	}
    room* roomInfo(room* headr)
    {
    		room*temp1=headr;
		if(temp1==0)
		{
			cout<<"List is empty!!";
			
		}
		else{
			 while(temp1!=0)
			 {
			 	if(temp1->occupied==0)
			 	{
			 		cout<<"\n###Room number: "<<temp1->roomnumber<<"\tGuest Name:"<<temp1->guestname<<"\t Room type: "<<temp1->roomtype<<endl;
			 		
			 		
				 }
				 else{
				 	cout<<"\n###Room number: "<<temp1->roomnumber<<"\tGuest Name:"<<temp1->guestname<<"\t Room type: "<<temp1->roomtype<<endl;
				 }
				 temp1=temp1->next;
			 }
		}
	
	}
    room* checkOut(int roomnumber,string guestname,bool occupied, room* headr) {
   
        room* temp = headr;
        guestname = temp->guestname;
        occupied=temp->occupied;
        while (temp!= 0) {
            if (temp->roomnumber == roomnumber) {
            	if(temp->occupied==true){
				
                    string guestname = temp->guestname;
                     
                   
                    cout << guestname << " checked out from room " << roomnumber << "." << endl;
                 
                } }else {
                    cout << "Room " << roomnumber << " is not occupied." << endl;
                    
                }
                  temp = temp->next;
            }
          
         return headr;
   }
      
    
    void calculateBill() {
    	roomInfo(headr);
    	double totalBill=0;
    	int roomnumber,numDays,pricePerDay;
    	cout<<"Enter the Room Number:";
    	cin>>roomnumber;
    	cout<<"Enter Number of days for Room reservation:";
    	cin>>numDays;
    	cout<<"Enter price of Room for per day Reservation:";
    	cin>>pricePerDay;
    room* temp = headr;
    
    while (temp != 0) {
        if (temp->roomnumber == roomnumber) {
           
                 totalBill = numDays * pricePerDay;
                
            } 
        
        temp = temp->next;
    }
   	cout<<"----------------------------------------------------\n";
  cout<<"\nThe Total Bill of Room  is "<<totalBill<<endl;
  	cout<<"----------------------------------------------------\n";
}



    room* deleteRoom()
    {
    		cout<<"Enter the guest name which is to be deleted:";
		string name;
		cin>>name;
		room* temp=headr;
		while(temp!=0)
		{
			if(temp->guestname==name)
			{
			
			headr=cancelReservation(name, headr);
			
		}
			temp=temp->next;
		}
		return headr;
		cout<<"Room Reservation is Cancelled!!!";
	   
	}
    
    void adminMenu()
    {
    	
    	cout<<"\n\n1)Add new item in the Menu\n2)Delete item from the menu\t\n3)Display order menu\t\n4)Back to main menu\n\nEnter Your choice:";
    	
	}
    void customerMenu()
    {
    	
    	cout<<"\n1)Place Your Order\n2)View your Ordered Items\t\n3)Delete an item from your Order\t\n4)Display the final Bill\t\n5)Back to main menu\n\nEnter Your choice:";
    	
	}
	void roomReservationMenu()
	{
		cout<<"1)Add room \n2)Check In\n3)Check out\n4)Display Room Info\n5)Cancel Reservation\n6)Calculate Room bill\n7)Exit\n Enter your choice-->";
	}
	node* createAdmin(node* head,int orderNumber,string foodname,double price)
	{
	  
	  node* newNode=new node();

	  newNode->orderNumber=orderNumber;
	  newNode->foodName=foodname;
	  newNode->price=price;
	  newNode->quantity=0;
	  newNode->next=0;
	  
	  node* temp=head;
	  if(temp==0)
	{
		heada=taila=newNode;
	}
	else{
	node* temp=heada;
	while(temp->next!=0)
	{
		temp=temp->next;
	}
 temp->next=newNode;
 taila=newNode;
	}
	  return heada;

	}
node* createCustomer(node* head,int orderNumber,int quantity)
	{
		node* temp1=heada;
		
        bool flag;
		 node* newNode=new node();

		while(temp1!=0)
		{
			if(temp1->orderNumber==orderNumber)
			{
				flag=1;
				break;
			}
			temp1=temp1->next;
			
	}
	
		if(flag==1)
		{
			newNode->orderNumber=orderNumber;
			newNode->price=quantity*(temp1->price);
			newNode->quantity=quantity;
			newNode->foodName=temp1->foodName;
			newNode->next=0;
			node* temp=head;
			if(temp==0)
	{
		headc=tailc=newNode;
		
	}

	else{

	while(temp->next!=0)
		temp=temp->next;
 temp->next=newNode;
 tailc=newNode;
}

}
	  else{
	  	cout<<"Item is not present in the menu!!\n";
	  }
	  
	return headc;
		}
	
	
	void displayOrder(node* head)
	{
		node*temp1=head;
		if(temp1==0)
		{
			cout<<"List is empty!!";
			
		}
		else{
			 while(temp1!=0)
			 {
			 	if(temp1->quantity==0)
			 	{
			 		cout<<"\n###Food No.: "<<temp1->orderNumber<<"\tFood Name: "<<temp1->foodName<<"  Food Price:"<<temp1->price<<endl;
			 		
			 		
				 }
				 else{
				 	cout<<"\n###Food No.: "<<temp1->orderNumber<<"\tFood Name: "<<temp1->foodName<<"  Food Price:"<<temp1->price<<"  Food Quantity:"<<temp1->quantity<<endl;
				 }
				 temp1=temp1->next;
			 }
		}
	}
	node* deleteData(int orderNumber, node* head1, node* tail)
{
    if (head1 == 0)
    {
        cout << "List is empty!" << endl;
        return 0;
    }
    
    if (orderNumber == head1->orderNumber)
    {
        node* temp = head1;
        head1 = head1->next;
        delete temp;
        return head1;
    }
    
    node* current = head1;
    while (current->next != 0)
    {
        if (orderNumber == current->next->orderNumber)
        {
            node* temp = current->next;
            current->next = current->next->next;
            delete temp;
            if (current->next == 0)
                tail = current;
            return head1;
        }
        current = current->next;
    }
    
    cout << "Food item with serial number " << orderNumber << " not found in the list!" << endl;
    return head1;
}

	int deleteadmin()
	{
		cout<<"Enter the serial number of the food item which is to be deleted:";
		int num;
		cin>>num;
		node* temp=heada;
		while(temp!=0)
		{
			if(temp->orderNumber==num)
			{
			
			heada=deleteData(num,heada,taila);
			return 1;
		}
			temp=temp->next;
		}
		cout<<"Item is deleted!!!";
	    return 0;
	}
	int deletecustomer()
	{
		cout<<"Enter the serial number of the food item which is to be deleted:";
		int num;
		cin>>num;
		node* temp=heada;
		while(temp!=0)
	    {
			if(temp->orderNumber==num)
			{
			
			headc=deleteData(num,headc,tailc);
			return 1;
		}
			temp=temp->next;
		}
	    return 0;
	}
	void displayBill()
	{
		displayOrder(headc);
		node* temp=headc;
		float totalPrice=0;
		while(temp!=0)
		{
			totalPrice+=(temp->quantity)*(temp->price);
			temp=temp->next;
		}
		cout<<"----------------------------------------------------\n";
		cout<<"The total bill of ordered Food is: "<<totalPrice<<endl;
		cout<<"----------------------------------------------------\n";
		
	}
	node* deleteList(node* head)
	{
		node* n;
			node* temp=head;
		if(head==0){
			cout<<"List is empty!!";
		}
		else{
		
			while(temp!=0)
			{
				n=temp->next;
				delete temp;
				
			}
			head=0;
		}
		return head;
	}
	void admin()
	{
			 node* temp=heada;
		cout<<"-------------------------------------------------------------\n";
		cout<<"                      ADMIN SECTION\n";
		cout<<"-------------------------------------------------------------\n";
		while(1)
		{
			adminMenu();
			int a,i=0;
			cin>>a;
			
			if(a==4)
			break;
			
			int num,flag;
				 string name;
				 float price;
				 
			
			switch(a)
			{
				
				case 01:
			   	cout<<" ******** RESTURANT MENU ********* \n";
					displayOrder(heada);
				 cout<<"Enter the serial number of food item:";
				 
				 cin>>num;
				 
				 
				 while(temp!=0)
				 {
				 	if(temp->orderNumber==num)
				 	{
				 		cout<<"food item with given serial number already exist!!";
				 		flag=1;
				 		return;
					 }
					 temp=temp->next;
					 
				 }
				 if(flag==1)
				 {
				 	break;
				 }
				 cout<<"Enter Food Name: ";
				 cin>>name;
				 cout<<"Enter price:";
				 cin>>price;
				 heada=createAdmin(heada,num,name,price);
				 cout<<"Food item added to the list!!!";
				 break;
			
			case 02:
				if(deleteadmin())
				{
					cout<<"###Updated list of foode item menu:\n";
					displayOrder(heada);
					
				}
				else
				{
					cout<<"Food item with given number is not available!!!";
				}
				break;
			case 03:
					cout<<"Order Menu:";
					displayOrder(heada);
					break;
			default:
					cout<<"Wrong Input please choose valid option..";
					break;
			}
		}
	}
	void customer()
	{
		int flag=0,j=1;
		char ch;
		cout<<"-------------------------------------------------------------\n";
		cout<<"                        CUSTOMER SECTION\n";
		cout<<"-------------------------------------------------------------\n";
		while(1)
		{
			customerMenu();
			int opt;
			cin>>opt;
			if(opt==5)
			{
				break;
			}
			int rnum;
					string gname;
			switch(opt)
			{
			
			  case 01:
			  
			  	cout<<" ******** RESTURANT MENU ********* \n";
			  
			     displayOrder(heada);
				 cout<<"Enter the number corresponding to the item you want: ";
				 int n;
				 cin>>n;
				 cout<<"Enter the Qunatity:";
				 int quantity;
				 cin>>quantity;
				 
				 headc=createCustomer(headc,n,quantity);
				 break;
			  case 02:
			  cout<<"List of ordered item:";
			  displayOrder(headc);
			  break;
			  case 03:
			  deletecustomer();
			  	
			  		cout<<"Updated List of ordered food items:";
			  		displayOrder(headc);
				 
				  	break;
				  
			case 04:
				cout<<"Final Bill:";
				displayBill();
				cout<<"Press any key to return to main menu:";
				fflush(stdin);
				ch=fgetc(stdin);
				flag=1;
				break;
			default:
				cout<<"Wrong input!! Please choose valid option....";
				break;
				
			  			}
			if(flag==1)
			break;
		}
	}
		void RoomReservation()
	{
		int flag=0,ch;
			int rnum,numdays;
			float pricePerDays;
			string roomtype;
			string gname;	
		bool b;	
			cout<<"-------------------------------------------------------------\n";
		cout<<"                        ROOM RESERVATION SECTION\n";
		cout<<"-------------------------------------------------------------\n";
		while(1)
		{
		 roomReservationMenu();
			int opt;
			cin>>opt;
			if(opt==8)
			{
				break;
			}

			switch(opt)
			{
					case 01:
						cout<<"\n******Available Rooms*****\n";
					
					cout<<"###Room Number: 345      Room Type: Deluxe           Room Price: 4500\n";
					cout<<"###Room Number: 346      Room Type: LuxuryDeluxe     Room Price: 5500\n";
					cout<<"###Room Number: 347      Room Type: Deluxesuite      Room Price: 4500\n";
					cout<<"###Room Number: 348      Room Type: Normal           Room Price: 3500\n";
					cout<<"###Room Number: 349      Room Type: Luxury           Room Price: 6500\n";
					cout<<"\n*****For Room Reservation*****\n";
		                 
						cout<<"Enter guest name:";
						cin>>gname;
						cout<<"Enter room type:";
						cin>>roomtype;
						cout<<"Enter room Number:";
						cin>>rnum;
					   
						headr=addRoom(headr,rnum,b,gname,roomtype);
				
						cout<<"\n###List:";
						roomInfo(headr);
						
				
					break;
				case 02:
				
					cout<<"Check In details, give room number";
					cin>>rnum;
			
								headr=checkIn(rnum,gname,b,headr);
					roomInfo(headr);
					break;
			   case 03:
			 	
					cout<<"Check Out details, give room number";
					cin>>rnum;
			
					headr=checkOut(rnum,gname,b,headr);
				
					break;
				case 04:
						
				
					cout<<"###Updated list of  Room Reservation:\n";
				    roomInfo(headr);
					break;
			    case 05:
			    	
						if(deleteRoom()){
						
			  	
			  		cout<<"Updated List of Room List:";
			        roomInfo(headr);
			        
					}
					else{
					
			        break;
			    }
				  
				case 06:
			         	cout<<"\n******Prices of Rooms*****\n";
					cout<<"###Room Number: 345      Room Type: Deluxe           Room Price: 4500\n";
					cout<<"###Room Number: 346      Room Type: LuxuryDeluxe     Room Price: 5500\n";
					cout<<"###Room Number: 347      Room Type: Deluxesuite      Room Price: 4500\n";
					cout<<"###Room Number: 348      Room Type: Normal           Room Price: 3500\n";
					cout<<"###Room Number: 349      Room Type: Luxury           Room Price: 6500\n";
					
				
					calculateBill();
					break;
			
				case 07:
						cout<<"Press any key to return to main menu:";
				fflush(stdin);
				ch=fgetc(stdin);
				flag=1;
				break;
						default:
				cout<<"Wrong input!! Please choose valid option....";
				break;
				
			  			}
				if(flag==1)
			break;
	}
}

	
    int main() {
    int choice;
       heada=createAdmin(heada,1,"Hot and Sour Soup",100.0);
        heada=createAdmin(heada,2,"Manchow soup",1200.0);
        heada=createAdmin(heada,3,"Manchurian Noodles",250.0);
         heada=createAdmin(heada,4,"Fried Rice",300.0);
          heada=createAdmin(heada,5,"Hakka Noodles",180.0);

          
          
        do{
		
		  int ch;
		cout<<"\n********************************************************\n";
		cout<<"            WELCOME TO HOTEL MANAGEMENT SYSTEM    \n";
		cout<<"**********************************************************\n";
		cout<<"   1) ADMIN SECTION\n";
		cout<<"   2) CUSTOMER SECTION\n";
		cout<<"   3) ROOM RESERVATION SECTION\n";
		cout<<"   4) Return to Main Menu\n";
		cout<<"   5)Exit--->\n";
		cout<<"   Enter your Choice:";
        cin>>choice;
    
		  switch(choice)
		  {
		  	case 01:
		  		 admin();
		  		 break;
		  	case 02:
			     customer();
				 break;
			case 03:
				 RoomReservation();
			 break;
			case 04:
		cout<<"Press any key to return to main menu:";
				fflush(stdin);
				ch=fgetc(stdin);
				break;
				case 05:
					exit(0);
					break;
			 default:
			   cout<<"Invalid Input!!!Please Choose valid Option....\n";
			   break;	 	 
		  }
	
}while(choice!=6);
		  return 0;
   }
